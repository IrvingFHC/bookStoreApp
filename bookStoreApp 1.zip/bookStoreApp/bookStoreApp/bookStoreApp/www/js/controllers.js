angular.module('starter.controllers', [])

.controller('PagController', function($scope){

})
