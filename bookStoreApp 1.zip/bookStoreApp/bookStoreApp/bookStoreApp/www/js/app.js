
	var books = [
		{
			fecha:'27/04/16',
			pedido: '7',
			estado:'PAGADO',
			total:'140',
			name: 'El alquimista',
			id:"1",
			autor:"Paulo Coelho",
			editorial:"Editorial: Espasa",
			description: 'El alquimista (O Alquimista, 1988) es un libro escrito por el brasileño Paulo Coelho que ha sido traducido a más de 63 lenguas y publicado en 150 países, y que ha vendido 65 millones de copias en todo el mundo (2012). El libro trata sobre los sueños y los medios que utilizamos para alcanzarlos, sobre el azar en nuestra vida y las señales que se presentan a lo largo de esta.',
			image: [
				{url:'img/alquimista.jpg'}
			]
		},
		{
			fecha:'30/05/16',
			pedido: '3',
			estado:'NO PAGADO',
			total:'200',
			name: 'Ana Frank',
			id:"2",
			autor:"Ana Frank",
			editorial:"Editorial: De bolsillo",
			description: 'Con el título de El diario de Ana Frank se conoce la edición de los diarios personales escritos por la niña judía Ana Frank (Annelies Marie Frank) entre el 12 de junio de 1942 y el 1 de agosto de 1944 en un total de tres cuadernos conservados a la actualidad, donde relata su historia como adolescente y el tiempo de dos años cuando tuvo que ocultarse de los nazis en Ámsterdam, durante la Segunda Guerra Mundial.',
			image: [
				{url:'img/ana.jpg'}
			]
		},
		{
			fecha:'31/05/16',
			pedido: '10',
			estado:'PAGADO',
			total:'100',
			name: 'El psicoanalista',
			id:"3",
			autor:"John Katzenbach",
			editorial:"Editorial: EDICIONES B",
			description: 'El Psicoanalista es un thriller psicológico y la novela más exitosa de John Katzenbach. Publicada por primera vez en 2002, y en 2003 su edición en español lanzada en España, Chile, Argentina, Colombia, Venezuela, México, Uruguay y Ecuador, donde se mantuvo entre los más vendidos. La historia pone a prueba la capacidad del protagonista para evitar el suicidio frente a la presión de un desconocido. Este autor destaca por el realismo psicológico de sus personajes y la capacidad de establecer una trama intrigante.',
			image: [
				{url:'img/psicoanalista.jpg'}
			]
		}	
	];

	var clientes = [
		{
			name: "Diego",
			age: 21,
			email: '',
			direccion: 'Villa',
			contraseña: 'xxxxxx'
		},
		{
			name: "Fernando",
			age: 22,
			email: '',
			direccion: 'Del Real',
			contraseña: 'xxxxxx'
		}
	];

var app = angular.module('bookStoreApp', ['ui.router']);

	app.controller('BookStoreController', function(){
		this.inventarios = books;
		this.person = clientes;
	});

/*estados states*/
	app.config(function($stateProvider, $urlRouterProvider){
  $stateProvider
  .state('dashboard',{
    url: '/dashboard',
    templateUrl: 'templates/dashboard.html',
    controller: 'BookStoreController'
  })
  .state('mis-pedidos',{
    url: '/mis-pedidos',
    templateUrl: 'templates/mis-pedidos.html',
    controller: 'BookStoreController'
  })
  .state('libros',{
    url: '/libros',
    templateUrl: 'templates/libros.html',
    controller: 'BookStoreController'
  })
.state('mis-datos',{
    url: '/mis-datos',
    templateUrl: 'templates/mis-datos.html',
    controller: 'BookStoreController'
  })
.state('mis-favoritos',{
    url: '/mis-favoritos',
    templateUrl: 'templates/mis-favoritos.html',
    controller: 'BookStoreController'
  })
.state('mis-pedidos-ficha',{
    url: '/mis-pedidos-ficha',
    templateUrl: 'templates/mis-pedidos-ficha.html',
    controller: 'BookStoreController'
  })


  $urlRouterProvider.otherwise('libros');
});